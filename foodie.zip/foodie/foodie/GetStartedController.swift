//
//  ViewController.swift
//  foodie
//
//  Created by Thenura Jayasinghe on 2021-03-25.
//

import UIKit

class GetStartedController: UIViewController {

    @IBOutlet weak var getStartedButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getStartedButton.layer.cornerRadius = 10

    }
    

}

